extends Node2D
class_name PresenceRW

## Grid-following monster controller.
##
## Responsibilities:
## - Maintain monster position in cell-space (Vector2i).
## - Move on an interval to a neighboring walkable cell.
## - Choose a history-based target ("behind" the player) and chase it.
## - Use the player's trail value as a tie-breaker.
## - Provide a 0..1 pressure value for UI based on distance to the player.
##
## Design goals:
## - Keep all grid/path logic in GameController, and keep this node focused on
##   behavior/decision making.

@export var controller_path: NodePath
@export var move_interval: float = 1.0
@export var wander_if_no_trail: bool = true

@export var near_cells: int = 4
@export var far_cells: int = 25
@export var catch_distance_cells: int = 0

@export var debug_draw: bool = true
@export var debug_radius: float = 6.0
@export var debug_color: Color = Color(1, 0, 0, 0.95)

# How far behind the player history to aim (used by _choose_history_target).
@export var behind_steps: int = 14

# Respawn tuning (history-based spawning)
@export var history_tail_exclusion: int = 18          # newest steps never eligible
@export var min_dist_cells: int = 8                   # must be at least this far from player
@export var max_dist_cells: int = 60                  # ignore super-old/far history
@export var pick_from_best_fraction: float = 0.25     # pick randomly from best N%

@export var sniff_interval: float = 0.9     # slower movement while sniffing
@export var hunt_interval: float = 0.35     # faster movement while hunting
@export var los_range_cells: int = 4        # LOS distance in cells
@export var scent_focus: float = 6.0        # how strongly it prefers higher scent
@export var goal_focus: float = 2.0         # how strongly it prefers progress toward target

const INVALID_CELL := Vector2i(-999999, -999999)
const OFFMAP_POS := Vector2(-1000000.0, -1000000.0)

# Public-ish state (kept for compatibility with your existing code)
var cell: Vector2i = INVALID_CELL

# Internal state
var _active := false
var _prev_cell: Vector2i = INVALID_CELL
var _target_cell: Vector2i = INVALID_CELL
var _timer: float = 0.0
var _rng := RandomNumberGenerator.new()
var _hunting: bool = false

var _last_seen_player: Vector2i = INVALID_CELL
var _search_timer: float = 0.0
@export var search_memory_time: float = 2.5 # seconds it keeps "last seen" hunt after LOS breaks

@export var door_try_scent_threshold: float = 0.05 # in sniff mode, only try doors if local scent is at least this
@export var random_turn_chance_sniff: float = 0.08  # adds fallibility

@onready var controller: GameController = _resolve_controller()

func _ready() -> void:
	_rng.randomize()
	# If this node starts without a valid cell, ensure it can't accidentally trigger anything.
	if cell == INVALID_CELL:
		deactivate()

func _process(delta: float) -> void:
	if not _active:
		return

	var saw := _has_los_to_player(los_range_cells)

	if saw:
		_hunting = true
		_search_timer = search_memory_time
		_last_seen_player = controller.world_to_cell(controller.player.global_position)
	else:
		# keep hunting briefly even after losing LOS
		if _search_timer > 0.0:
			_search_timer = maxf(0.0, _search_timer - delta)
			_hunting = true
		else:
			_hunting = false

	var interval := (hunt_interval if _hunting else sniff_interval)

	_timer += delta
	if _timer >= interval:
		_timer = 0.0
		_step()

	_check_catch()

func _draw() -> void:
	if debug_draw and _active:
		draw_circle(Vector2.ZERO, debug_radius, debug_color)

func _resolve_controller() -> GameController:
	# Prefer explicit path, fall back to "../GameController" for backwards compatibility.
	var gc: GameController = null
	if controller_path != NodePath():
		gc = get_node_or_null(controller_path) as GameController
	if gc == null:
		gc = get_node_or_null("../GameController") as GameController
	return gc

func _snap_to_cell() -> void:
	if controller == null:
		return
	if cell == INVALID_CELL:
		return
	global_position = controller.cell_to_world_center(cell)
	queue_redraw()

func _ensure_initialized_from_world() -> void:
	if controller == null:
		return
	if cell != INVALID_CELL:
		return
	cell = controller.world_to_cell(global_position)
	_prev_cell = cell
	_target_cell = INVALID_CELL
	_snap_to_cell()

# -----------------------------------------------------------------------------
# Public API
# -----------------------------------------------------------------------------

func deactivate() -> void:
	_active = false
	cell = INVALID_CELL
	_prev_cell = INVALID_CELL
	_target_cell = INVALID_CELL
	_timer = 0.0

	# Make it "exist nowhere" until you intentionally spawn it.
	global_position = OFFMAP_POS

	# Optional but helpful: guarantees no accidental interactions/visuals.
	visible = false
	set_process(false)
	set_physics_process(false)
	queue_redraw()

func activate() -> void:
	_active = true
	visible = true
	set_process(true)
	set_physics_process(true)
	_timer = 0.0
	# If we already have a valid cell, snap immediately.
	_snap_to_cell()
	queue_redraw()

func is_active() -> bool:
	return _active

func respawn_far_from_player(min_dist: int = 18, attempts: int = 800) -> void:
	if controller == null or controller.player == null:
		return

	var p_cell: Vector2i = controller.world_to_cell(controller.player.global_position)
	var size: Vector2i = controller.grid_size_cells()

	# If bounds are unknown, fall back to a nearby valid neighbor.
	if size == Vector2i.ZERO:
		for n in controller.get_neighbors4(p_cell):
			if controller.is_walkable(n):
				cell = n
				_prev_cell = cell
				_target_cell = INVALID_CELL
				activate()
				return
		cell = p_cell
		_prev_cell = cell
		_target_cell = INVALID_CELL
		activate()
		return

	for _i in range(attempts):
		var c := Vector2i(_rng.randi_range(0, size.x - 1), _rng.randi_range(0, size.y - 1))
		if not controller.is_walkable(c):
			continue
		var md: int = abs(c.x - p_cell.x) + abs(c.y - p_cell.y)
		if md < min_dist:
			continue
		cell = c
		_prev_cell = cell
		_target_cell = INVALID_CELL
		activate()
		return

	# Last-ditch fallback.
	for n in controller.get_neighbors4(p_cell):
		if controller.is_walkable(n):
			cell = n
			_prev_cell = cell
			_target_cell = INVALID_CELL
			activate()
			return

func get_pressure01() -> float:
	# Critical: no pressure/heartbeat while inactive or unspawned.
	if not _active:
		return 0.0
	if controller == null or controller.player == null:
		return 0.0
	if cell == INVALID_CELL:
		return 0.0

	var p_cell: Vector2i = controller.world_to_cell(controller.player.global_position)
	var d: int = controller.path_distance(cell, p_cell)
	# closer -> higher pressure
	var t := inverse_lerp(float(far_cells), float(near_cells), float(d))
	return clampf(t, 0.0, 1.0)

func respawn_from_room_start() -> bool:
	if controller == null or controller.player == null:
		return false

	var history: Array[Vector2i] = controller.player_history
	if history.is_empty():
		return false

	var player_cell: Vector2i = controller.world_to_cell(controller.player.global_position)

	# Cut off future-branch if player backtracked
	var prev_same := -1
	for i in range(history.size() - 2, -1, -1):
		if history[i] == player_cell:
			prev_same = i
			break

	# Keep a small tail exclusion so we don't pop right next to the player.
	var max_tail := maxi(0, history.size() - 1 - 2) # keep at least 2 cells available
	var tail := mini(history_tail_exclusion, max_tail)
	var last_allowed := maxi(0, history.size() - 1 - tail)

	var cutoff := last_allowed
	if prev_same != -1:
		cutoff = mini(cutoff, prev_same)

	# Prefer spawning at a room entrance: corridor (deg<=2) -> room (deg>=3)
	for i in range(cutoff, 0, -1):
		var cur := history[i]
		var prev := history[i - 1]
		if not controller.is_walkable(cur) or not controller.is_walkable(prev):
			continue

		var cur_deg := _walkable_degree(cur)
		var prev_deg := _walkable_degree(prev)
		if prev_deg <= 2 and cur_deg >= 3:
			if cur == player_cell:
				continue
			cell = cur
			_prev_cell = cell
			_target_cell = INVALID_CELL
			activate()
			return true

	# Fallback: oldest available cell on this branch
	var spawn_cell := history[0]
	for i in range(0, cutoff + 1):
		if controller.is_walkable(history[i]):
			spawn_cell = history[i]
			break

	if spawn_cell == player_cell:
		return false

	cell = spawn_cell
	_prev_cell = cell
	_target_cell = INVALID_CELL
	activate()
	return true

func respawn_from_history() -> bool:
	if controller == null:
		print("could not find controller")
		return false

	var history: Array[Vector2i] = controller.player_history
	if history.is_empty():
		print("history empty")
		return false

	# Prefer the real current player cell if we have a player ref
	var player_cell: Vector2i = controller.player_cell
	if controller.player != null:
		player_cell = controller.world_to_cell(controller.player.global_position)

	# Never exclude so much tail that we can't possibly be >= min_dist behind
	var max_tail := maxi(0, history.size() - 1 - min_dist_cells)
	var tail := mini(history_tail_exclusion, max_tail)
	var last_allowed := maxi(0, history.size() - 1 - tail)

	# If player backtracked, ignore the "future branch" after the previous visit
	var prev_same := -1
	for i in range(history.size() - 2, -1, -1):
		if history[i] == player_cell:
			prev_same = i
			break

	var cutoff := last_allowed
	if prev_same != -1:
		cutoff = mini(cutoff, prev_same)

	var pairs: Array[Dictionary] = [] # {"cell": Vector2i, "d": int}
	for i in range(0, cutoff + 1):
		var c: Vector2i = history[i]
		if not controller.is_walkable(c):
			continue

		var d: int = controller.path_distance(c, player_cell)
		if d >= 999999:
			continue
		if d < min_dist_cells or d > max_dist_cells:
			continue
		pairs.append({"cell": c, "d": d})

	if pairs.is_empty():
		print("pairs empty | hist=", history.size(),
			" tail_excl=", history_tail_exclusion,
			" last_allowed=", last_allowed,
			" cutoff=", cutoff,
			" prev_same=", prev_same,
			" player_cell=", player_cell,
			" min=", min_dist_cells,
			" max=", max_dist_cells)
		return false

	pairs.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["d"]) < int(b["d"]))

	var top_count := maxi(1, int(ceil(pairs.size() * pick_from_best_fraction)))
	var pick_index := _rng.randi_range(0, top_count - 1)
	cell = pairs[pick_index]["cell"]

	_prev_cell = cell
	_target_cell = INVALID_CELL # force re-target after respawn
	activate()
	return true

# -----------------------------------------------------------------------------
# Internal behavior
# -----------------------------------------------------------------------------

func _step() -> void:
	if controller == null or not _active:
		return

	_ensure_initialized_from_world()
	if cell == INVALID_CELL:
		return

	var neighbors := controller.get_neighbors4(cell)
	if neighbors.is_empty():
		return

	var next := INVALID_CELL

	# -------------------------
	# HUNT / SEARCH MODE
	# -------------------------
	if _hunting:
		# target = real player if LOS now, else last seen position
		var target := _last_seen_player
		if _has_los_to_player(los_range_cells):
			target = controller.world_to_cell(controller.player.global_position)
			_last_seen_player = target

		next = _choose_step_toward_target(neighbors, target, true)

	# -------------------------
	# SNIFF MODE
	# -------------------------
	if next == INVALID_CELL:
		next = _choose_step_by_scent(neighbors)

	# -------------------------
	# FINAL FALLBACK: wander
	# -------------------------
	if next == INVALID_CELL:
		for n in neighbors:
			if _try_make_walkable(n):
				next = n
				break

	if next == INVALID_CELL:
		return

	_prev_cell = cell
	cell = next
	_snap_to_cell()

func _check_catch() -> void:
	if not _active:
		return
	if controller == null or controller.player == null:
		return
	if catch_distance_cells < 0:
		return
	if cell == INVALID_CELL:
		return

	var p_cell: Vector2i = controller.world_to_cell(controller.player.global_position)
	var d: int = controller.path_distance(cell, p_cell)
	if d <= catch_distance_cells:
		_on_catch()

func _on_catch() -> void:
	get_tree().reload_current_scene()

func _walkable_degree(c: Vector2i) -> int:
	var d := 0
	for n in controller.get_neighbors4(c):
		if controller.is_walkable(n):
			d += 1
	return d

func _choose_history_target() -> void:
	if controller == null:
		_target_cell = INVALID_CELL
		return

	var history: Array[Vector2i] = controller.player_history
	if history.is_empty():
		_target_cell = INVALID_CELL
		return

	# Current player cell (if we can)
	var player_cell: Vector2i = controller.player_cell
	if controller.player != null:
		player_cell = controller.world_to_cell(controller.player.global_position)

	# Exclude newest tail so it doesn't magically track right onto the player
	var max_tail := maxi(0, history.size() - 1 - 1)
	var tail := mini(history_tail_exclusion, max_tail)
	var last_allowed := maxi(0, history.size() - 1 - tail)

	# Candidate scoring:
	# - Must be walkable
	# - Must be in a distance band from the player
	# - Prefer higher scent (trail) and not-too-far from the presence
	var best_candidates: Array[Dictionary] = [] # {"cell": Vector2i, "score": int}
	var best_score := -999999999

	for i in range(0, last_allowed + 1):
		var c: Vector2i = history[i]
		if not controller.is_walkable(c):
			continue
		if c == cell:
			continue

		var d_to_player := controller.path_distance(c, player_cell)
		if d_to_player >= 999999:
			continue
		if d_to_player < min_dist_cells or d_to_player > max_dist_cells:
			continue

		var d_to_me := controller.path_distance(cell, c)
		if d_to_me >= 999999:
			continue

		var t := controller.get_trail(c)

		# Prefer higher trail and nearer to presence; keep it behind-ish by your params.
		var score := int(round(t * 10.0)) - d_to_me

		if score > best_score:
			best_score = score
			best_candidates.clear()
			best_candidates.append({"cell": c, "score": score})
		elif score == best_score:
			best_candidates.append({"cell": c, "score": score})

	if best_candidates.is_empty():
		# Fallback: try your old "behind_steps" behavior
		var idx: int = max(0, history.size() - 1 - behind_steps)
		for j in range(idx, -1, -1):
			var cc: Vector2i = history[j]
			if controller.is_walkable(cc):
				_target_cell = cc
				return
		_target_cell = INVALID_CELL
		return

	# Pick randomly from top fraction to keep it from feeling robotic
	best_candidates.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return int(a["score"]) > int(b["score"])
	)

	var top_count := maxi(1, int(ceil(best_candidates.size() * pick_from_best_fraction)))
	var pick_index := _rng.randi_range(0, top_count - 1)
	_target_cell = best_candidates[pick_index]["cell"]

	
func _has_los_to_player(max_range: int) -> bool:
	if controller == null or controller.player == null:
		return false
	if cell == INVALID_CELL:
		return false

	var p_cell := controller.world_to_cell(controller.player.global_position)

	var dx := p_cell.x - cell.x
	var dy := p_cell.y - cell.y

	# Line of sight = same row or same column
	if dx != 0 and dy != 0:
		return false

	var steps :int= abs(dx) + abs(dy)
	if steps > max_range:
		return false
	if steps == 0:
		return true

	var step_dir := Vector2i(signi(dx), signi(dy))
	var c := cell

	# Check every tile between us and the player (inclusive of player cell)
	for i in range(steps):
		c += step_dir
		# treat closed doors as blocking LOS because is_walkable uses maze.is_floor (door mask)
		if not controller.is_walkable(c):
			return false

	return true
	
func _try_make_walkable(n: Vector2i) -> bool:
	if controller.is_walkable(n):
		return true
	return _try_open_if_door(n)

func _best_scent_neighbor(neighbors: Array[Vector2i]) -> Vector2i:
	var best := INVALID_CELL
	var best_scent := 0.0

	for n in neighbors:
		# scent can exist on blocked door tiles; read it first
		var s := controller.get_trail(n)
		if s < best_scent:
			continue

		# Only accept if we can actually move there (opening door if needed)
		if _try_make_walkable(n):
			best_scent = s
			best = n

	return best

func _choose_step_toward_target(neighbors: Array[Vector2i], target: Vector2i, allow_open_doors: bool) -> Vector2i:
	var best := INVALID_CELL
	var best_d := 999999

	var candidates := neighbors.duplicate()
	candidates.shuffle()

	# First pass: avoid backtrack
	for n in candidates:
		if n == _prev_cell:
			continue

		# For movement, we still need to be able to enter it (open door if needed)
		if not controller.is_walkable(n):
			if allow_open_doors and _try_open_if_door(n):
				pass
			else:
				continue

		var d :int= controller.path_distance_presence(n, _target_cell)
		if d <= best_d: # <= matters when lots of ties/999999 cases
			best_d = d
			best = n

	# Second pass: allow backtrack
	if best == INVALID_CELL:
		for n in candidates:
			if not controller.is_walkable(n):
				if allow_open_doors and _try_open_if_door(n):
					pass
				else:
					continue

			var d :int= controller.path_distance_presence(n, _target_cell)
			if d <= best_d:
				best_d = d
				best = n

	return best

func _choose_step_by_scent(neighbors: Array[Vector2i]) -> Vector2i:
	# Occasionally make a "bad" choice so it feels animal, not GPS
	if randf() < random_turn_chance_sniff:
		var shuffled := neighbors.duplicate()
		shuffled.shuffle()
		for n in shuffled:
			if _try_make_walkable(n):
				return n

	# Measure local scent
	var local_best := 0.0
	for n in neighbors:
		local_best = maxf(local_best, controller.get_trail(n))

	# If adjacent closed door exists and there is meaningful scent, try it
	if local_best >= door_try_scent_threshold:
		for n in neighbors:
			if _try_open_if_door(n):
				return n

	# Pure gradient: choose highest scent among walkable (doors can be opened by _try_make_walkable)
	var best := INVALID_CELL
	var best_s := -1.0
	var shuffled := neighbors.duplicate()
	shuffled.shuffle()

	for n in shuffled:
		var s := controller.get_trail(n)

		# bias against immediate backtracking unless it’s clearly better
		if n == _prev_cell:
			s *= 0.65

		if s < best_s:
			continue

		if _try_make_walkable(n):
			best_s = s
			best = n

	# If there is basically no scent, return INVALID so caller can fall back
	if best_s <= 0.0:
		return INVALID_CELL

	return best


func _try_open_if_door(n: Vector2i) -> bool:
	if controller.has_method("is_door_closed") and controller.has_method("try_open_door"):
		if bool(controller.call("is_door_closed", n)):
			return bool(controller.call("try_open_door", n))
	return false
